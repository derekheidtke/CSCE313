Here comes the source code for MP1. The following files are included:

-- ackerman.h / ackerman.c : These files contain all the code ready to exercise your allocator. Call the extern function "ackerman_main" from your main program.

-- my_allocator.h / my_allocator.c : Header file for the allocator.
Implementation file with placeholders for the implementations of the functions defined in the header. This code is operational as-is, but you need to replace the implementation with yours!

-- memtest.c : This file calls the "ackerman_main" function to exercise your allocator. You will need to add initialization and clean-up of the allocator on exit.

-- makefile : This file tells 'make' how to compile everything together.

